Hirochi Sunburst Cursors made by MH4

I love this game "too" much

128x cursors are mainly for 4k, it has white highlights when below level 3 cursor size on a HD monitor.
64x should work for any monitor. If 64x is too low for you, use 128x.
I can't export cursors above 128x.
If you notice anything wrong with the cursors or what to give some feedback, feel free to message me on deviant art.

Thank you very much for your support!